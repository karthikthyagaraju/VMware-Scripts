﻿##This script is written by Karthik Thyagaraju to reset the Stealth lab in Azure##

Import-Module "C:\Users\tkarthi1\OneDrive - Unisys\Scripts\Az.LabServices.psm1"

## TO CONNECT AZURE LAB SERVICES and ADD LAB Users ##

$lab = Get-AzLabAccount | Get-AzLab -LabName "Stealth-UU-Training-Lab"
$Email = Get-Content "C:\Users\tkarthi1\Desktop\Azure users.txt"
ForEach ($EmailID in $Email) {
Add-AzLabUser -Lab $lab -Emails $EmailID 
}

## TO REMOVE LAB Users and RESET the LAB ##

$lab = Get-AzLabAccount | Get-AzLab
$users  = Get-AzLabUser -Lab $lab 
ForEach ($user in $users) {
Remove-AzLabUser -User $user -Lab $lab 
}
