﻿$rgName = 'Stealth-UU-Lab-RG'
$vmName = 'Custom'
$vm = Get-AzVM -ResourceGroupName $rgName -Name $vmName
Stop-AzVM -ResourceGroupName $rgName -Name $vmName
$disk= Get-AzDisk -ResourceGroupName $rgName -DiskName $vm.StorageProfile.OsDisk.Name
$disk.DiskSizeGB = 350
Update-AzDisk -ResourceGroupName $rgName -Disk $disk -DiskName $disk.Name