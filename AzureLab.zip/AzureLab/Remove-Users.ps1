#Disable-AzContextAutosave –Scope Process
 
$Conn = Get-AutomationConnection -Name 'AzureRunAsConnection'
Connect-AzAccount -ServicePrincipal -Tenant $Conn.TenantID -ApplicationId $Conn.ApplicationID -CertificateThumbprint $Conn.CertificateThumbprint
$AzureContext = Select-AzSubscription -SubscriptionId $Conn.SubscriptionID 
$AzureContext 

Write-Output "Getting Lab account..."

$Lab = Get-AzLabAccount -ResourceGroupName "stealth-uu-lab-rg" -LabAccountName "stealth-uu-lab-account" | Get-AzLab -LabName "Stealth-UU-Training-Lab"

Write-Output "Removing Users from Lab account..."

$users  = Get-AzLabUser -Lab $Lab

function Send-TestEmail{
    [cmdletbinding()]
    Param (
    $To,
    $Cc
  
   )

   Process{

        #Provide SendGrid user name, if you are using Microsoft azure you will find the same from the portal   
        $sendgridusername = "azure_2c28ca15d7c8025fc0ddc134e6b20d4f@azure.com"
        #Enter the send grid password Note: this is not recommended for production. In production, the password should be encrypted
        $SecurePassword=ConvertTo-SecureString 'P@$$word1!' –asplaintext –force 
        $cred = New-Object System.Management.Automation.PsCredential($sendgridusername,$SecurePassword)
        $sub = "Azure Lab Reset"
        $body0 = $users.properties.email | out-string
        $body = "Below users has been removed and Lab is being reset with registration link open <br> $body0"
        $From = "AzureStealthLab@unisys.com"
        Send-MailMessage -From $From -To $To -Cc $Cc -Subject $sub -Body $body -Priority High -SmtpServer "smtp.sendgrid.net" -Credential $cred -UseSsl -Port 587 -BodyAsHtml
   }
}

Send-TestEmail -To "UnisysStealthTrainings@unisys.com" -Cc "stealthtrainingsupport@unisys.com"

ForEach ($user in $users) {
Remove-AzLabUser -User $user -Lab $Lab
}

Write-Output "Setting Open UserAccessMode in Lab account..."

Set-AzLab -Lab $Lab -UserAccessMode Open