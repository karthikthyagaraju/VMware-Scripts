$Conn = Get-AutomationConnection -Name 'AzureRunAsConnection'
Connect-AzAccount -ServicePrincipal -Tenant $Conn.TenantID -ApplicationId $Conn.ApplicationID -CertificateThumbprint $Conn.CertificateThumbprint
$AzureContext = Select-AzSubscription -SubscriptionId $Conn.SubscriptionID 
$AzureContext 

Write-Output "Getting Lab account..."

$Lab = Get-AzLabAccount -ResourceGroupName "stealth-uu-lab-rg" -LabAccountName "stealth-uu-lab-account" | Get-AzLab -LabName "Stealth-UU-Training-Lab"

Set-AzLab -Lab $Lab -UserAccessMode Restricted